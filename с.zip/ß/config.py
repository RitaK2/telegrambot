TOKEN = "5772117518:AAF0W3WTODCC7gjW_YgOFZAn6wjjxZRggoM"


keys ={
    "биткоин": "BTC",
    "эфириум": "ETH",
    "доллар": "USD"
}